
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');
const os = require('os');

const DATA_DIR = path.join(app.getPath('userData'), 'userdata');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const FILES = {
  accounts: path.join(DATA_DIR, 'accounts.json'),
  friends: path.join(DATA_DIR, 'friends.json'),
  servers: path.join(DATA_DIR, 'servers.json'),
  messages: path.join(DATA_DIR, 'messages.json'),
  avatarsDir: path.join(DATA_DIR, 'avatars')
};
if (!fs.existsSync(FILES.avatarsDir)) fs.mkdirSync(FILES.avatarsDir, { recursive: true });

function readJSON(file, def){ try{ if(!fs.existsSync(file)) { fs.writeFileSync(file, JSON.stringify(def||[])); return def||[] } return JSON.parse(fs.readFileSync(file)); } catch(e){ console.error('readJSON',e); return def||[] } }
function writeJSON(file, data){ fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

// initialize files
readJSON(FILES.accounts, []);
readJSON(FILES.friends, []);
readJSON(FILES.servers, []);
readJSON(FILES.messages, []);

let mainWindow;
let signalingServer = null;
let httpServer = null;
let io = null;

function createWindow () {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 780,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'public', 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

// IPC: Data store operations
ipcMain.handle('data:accounts:create', (event, acc) => {
  const accounts = readJSON(FILES.accounts, []);
  accounts.push(acc);
  writeJSON(FILES.accounts, accounts);
  return {ok:true};
});
ipcMain.handle('data:accounts:getByUsername', (event, username) => {
  const accounts = readJSON(FILES.accounts, []);
  return accounts.find(a=>a.username===username) || null;
});
ipcMain.handle('data:accounts:getById', (event, id) => {
  const accounts = readJSON(FILES.accounts, []);
  return accounts.find(a=>a.id===id) || null;
});
ipcMain.handle('data:friends:add', (event, rec) => {
  const friends = readJSON(FILES.friends, []);
  friends.push(rec);
  writeJSON(FILES.friends, friends);
  return {ok:true};
});
ipcMain.handle('data:friends:list', (event, userId) => {
  const friends = readJSON(FILES.friends, []);
  return friends.filter(f=>f.user===userId||f.friend===userId);
});
ipcMain.handle('data:servers:create', (event, srv) => {
  const servers = readJSON(FILES.servers, []);
  servers.push(srv);
  writeJSON(FILES.servers, servers);
  return {ok:true};
});
ipcMain.handle('data:servers:list', (event)=> readJSON(FILES.servers, []));
ipcMain.handle('data:messages:add', (event, msg) => {
  const messages = readJSON(FILES.messages, []);
  messages.push(msg);
  writeJSON(FILES.messages, messages);
  return {ok:true};
});
ipcMain.handle('data:messages:list', (event, filter) => {
  const messages = readJSON(FILES.messages, []);
  if(filter && filter.channelId) return messages.filter(m=>m.channelId===filter.channelId);
  return messages;
});
ipcMain.handle('avatar:choose', async (event, {userId})=>{
  const res = await dialog.showOpenDialog({properties:['openFile'], filters:[{name:'Images', extensions:['png','jpg','jpeg','gif']}] });
  if(res.canceled) return {ok:false};
  const src = res.filePaths[0];
  const ext = path.extname(src);
  const dest = path.join(FILES.avatarsDir, `${userId}${ext}`);
  fs.copyFileSync(src, dest);
  return {ok:true, path: dest};
});
ipcMain.handle('avatar:get', (event, {userId})=>{
  const files = fs.readdirSync(FILES.avatarsDir);
  const f = files.find(x=>x.startsWith(userId));
  if(!f) return null;
  return path.join(FILES.avatarsDir, f);
});

// Signaling server control
ipcMain.handle('start-signaling', async (event, port) => {
  if (signalingServer) return {ok:false, error:'server already running'};
  const appEx = express();
  httpServer = http.createServer(appEx);
  io = new Server(httpServer, {cors:{origin:'*'}});
  const users = {};

  io.on('connection', (socket) => {
    users[socket.id] = {id: socket.id};
    io.emit('peers', Object.keys(users));
    socket.on('join', (payload) => {
      users[socket.id] = payload || {id: socket.id};
      io.emit('peers', Object.keys(users));
      socket.emit('joined', {id: socket.id});
    });
    socket.on('signal', (data) => {
      if (data.to && io.sockets.sockets.get(data.to)) {
        io.to(data.to).emit('signal', Object.assign({}, data, {from: socket.id}));
      } else {
        io.emit('signal', Object.assign({}, data, {from: socket.id}));
      }
    });
    socket.on('message', (m) => io.emit('message', {from: socket.id, text: m.text, time: Date.now()}));
    socket.on('disconnect', () => { delete users[socket.id]; io.emit('peers', Object.keys(users)); });
  });

  return new Promise((resolve, reject) => {
    httpServer.listen(port, '0.0.0.0', () => {
      signalingServer = true;
      console.log('Signaling server listening on', port);
      // return helpful addresses (renderer can query via IPC as well)
      resolve({ok:true, port, addresses: getNetworkAddresses()});
    });
    
    httpServer.on('error', (e) => { reject({ok:false, error: e.message}); });
  });
});

ipcMain.handle('stop-signaling', async (event) => {
  if (!httpServer) return {ok:false, error:'no server'};
  return new Promise((resolve) => {
    io && io.close();
    httpServer.close(() => {
      signalingServer = null;
      httpServer = null;
      io = null;
      resolve({ok:true});
    });
  });
});


// --- Network helpers (ZeroTier friendly) ---
function getNetworkAddresses() {
  const ifaces = os.networkInterfaces();
  const addrs = [];
  Object.keys(ifaces).forEach((name) => {
    ifaces[name].forEach((iface) => {
      if (iface.internal) return;
      // prefer IPv4
      if (iface.family === 'IPv4') {
        addrs.push({ iface: name, address: iface.address });
      }
    });
  });
  // try to prioritize ZeroTier interfaces by name or typical 10.* range
  addrs.sort((a,b)=>{
    const aZ = /zerotier|zt|zt0|zero/i.test(a.iface) || /^10\./.test(a.address);
    const bZ = /zerotier|zt|zt0|zero/i.test(b.iface) || /^10\./.test(b.address);
    return (bZ?1:0) - (aZ?1:0);
  });
  return addrs;
}

// Expose via IPC so renderer can auto-fill ZeroTier IP
ipcMain.handle('network:getAddresses', () => {
  try {
    return getNetworkAddresses();
  } catch(e) {
    return [];
  }
});
