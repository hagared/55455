
MiniMessenger — Capacitor Android wrapper
=======================================

This package prepares your existing web app (the Electron messenger frontend) to run on Android using Capacitor.
It does NOT build an APK here — it prepares the project that you can open in Android Studio and build.

What is included:
- www/        -> the web app assets (copied from public/)
- package.json
- capacitor.config.json
- README with build instructions

How to create APK (step-by-step):

1) Install Node.js and Java JDK (11+), Android Studio (with Android SDK).
2) Unzip this project and open a terminal in the project folder.
3) Install Capacitor CLI (optional local):
   npm install

4) Initialize Capacitor (only if running first time):
   npx cap init
   (the provided capacitor.config.json already contains appId/appName, so this step is optional)

5) Add Android platform:
   npx cap add android

6) Copy web assets into the native project (already present in www/):
   npx cap copy android

7) Open Android Studio:
   npx cap open android
   - In Android Studio, build or run on device. This will produce an APK or install directly.
   - If you encounter signing issues, use the 'Build > Generate Signed Bundle / APK' flow.

Notes:
- The web app expects to be able to call the signaling server at an address you provide.
  Use ZeroTier and the hosted PC IP (10.x.x.x) as before: e.g. http://10.147.20.7:3000
- If you need deep integration (background service, push notifications), we'll need to add native plugins.
- I can prepare a GitHub Actions workflow to build the APK in CI if you prefer automatic builds.
