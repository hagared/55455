
const api = window.electronAPI;
let socket = null;
let myAccount = null;

function $(id){return document.getElementById(id);}

async function populateInterfaces(){
  const list = await api.getAddresses();
  const sel = $('ifaces');
  sel.innerHTML = '';
  if(!list || list.length===0){
    const opt = document.createElement('option'); opt.textContent = 'No interfaces found'; sel.appendChild(opt); return;
  }
  list.forEach((it)=>{
    const o = document.createElement('option');
    o.value = it.address;
    o.textContent = `${it.iface} — ${it.address}`;
    sel.appendChild(o);
  });
  // try to preselect first ZeroTier-like interface
  for(let i=0;i<sel.options.length;i++){
    const txt = sel.options[i].text.toLowerCase();
    if(txt.includes('zerotier') || txt.includes('zt') || sel.options[i].value.startsWith('10.')){
      sel.selectedIndex = i; break;
    }
  }
  // if remoteUrl empty, set to first option
  if(!$('remoteUrl').value) $('remoteUrl').value = sel.value ? 'http://'+sel.value+':3000' : '';
}

window.addEventListener('DOMContentLoaded', async ()=>{
  await populateInterfaces();
  // refresh button
  $('useIface').onclick = ()=>{
    const sel = $('ifaces');
    if(sel && sel.value) $('remoteUrl').value = 'http://'+sel.value+':3000';
  };
  // connect
  $('connectRemote').onclick = ()=>{
    const url = $('remoteUrl').value.trim();
    if(!url) return alert('Введите адрес');
    if(socket) socket.disconnect();
    socket = io(url);
    socket.on('connect', ()=>{ socket.emit('join', {account: myAccount}); alert('Connected'); });
    socket.on('message', (m)=>{ $('messages').innerHTML += '<div><b>Peer</b>: '+m.text+'</div>'; });
    socket.on('signal', (s)=>{ console.log('signal', s); });
    socket.on('peers', (p)=>{ console.log('peers', p); });
  };
  // start server
  $('startServer').onclick = async ()=>{
    const port = parseInt($('signalPort').value || '3000',10);
    const res = await api.startSignaling(port);
    if(res.ok){
      alert('Signaling server started on port '+port);
      // show addresses to user
      const addrs = res.addresses || await api.getAddresses();
      console.log('addresses', addrs);
      alert('Addresses:\\n' + (addrs.map(a=>a.iface+': '+a.address).join('\\n')) );
    } else alert('Ошибка: '+res.error);
  };
  // account create
  $('createAccount').onclick = async ()=>{
    const username = $('username').value.trim(); const display = $('display').value.trim() || username;
    if(!username) return alert('Введите логин');
    const id = 'u_'+Math.random().toString(36).slice(2,9);
    const r = await api.accountsCreate({id, username, displayName: display});
    if(r.ok){ myAccount = {id, username, displayName: display}; $('meInfo').textContent = 'Вы: '+display+' ('+username+')'; }
  };
  // send message (to channel or broadcast)
  $('sendMsg').onclick = ()=>{
    const txt = $('msgInput').value.trim(); if(!txt) return;
    if(socket) socket.emit('message', {text: txt});
    else alert('Not connected');
    $('msgInput').value = '';
  };
});
