const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', {
  startSignaling: (port)=>ipcRenderer.invoke('start-signaling', port),
  stopSignaling: ()=>ipcRenderer.invoke('stop-signaling'),
  getAddresses: ()=>ipcRenderer.invoke('network:getAddresses')
});